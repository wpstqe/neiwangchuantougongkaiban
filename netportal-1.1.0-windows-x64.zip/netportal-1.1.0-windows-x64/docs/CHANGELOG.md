# Changelog

本文件记录 NetPortal 的主要变更。格式遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)。

## [1.1.0] - 2026-08-25

### 新增

**P1: TLS 大包修复**
- SSL_write 单次最大写入 64KB，避免大缓冲区触发 OpenSSL 记录层异常
- 优雅关闭 TLS 连接：收到 close_notify 后回复 close_notify
- `do_read()` 中 SSL_ERROR_ZERO_RETURN 时正确发送关闭响应

**P2: SO_REUSEPORT 多进程端口共享**
- 服务端配置 `[common] reuse_port=1` 启用 SO_REUSEPORT
- 所有监听套接字（控制/数据/代理/HTTP vhost）支持内核负载均衡
- 内核不支持时自动降级并记录警告日志

**P3: admin 管理面 API 扩展**
- 节点管理：列表/审批/禁用/启用/踢下线/配置下发（6 个端点）
- License 管理：状态查询/导入（2 个端点）
- 审计日志查询（1 个端点）
- 短期凭证签发（1 个端点）
- Prometheus 指标代理（1 个端点）
- 所有端点需 Bearer Token 认证

**P4: Vue3 前端控制台（np-console）**
- 仪表盘：在线节点/活跃会话/流量统计/代理列表
- 节点管理：列表/审批/禁用/启用/踢下线
- License 管理：状态展示/导入
- 审计日志：事件查询/分页
- Prometheus 指标：原始文本展示
- Vite 构建输出到 `admin/public/console`

### 修复
- TLS 数据通道大包（>16MB）`unexpected eof` 问题已修复

### 变更
- 版本号升级到 1.1.0
- admin README 更新完整 API 文档

## [1.0.0] - 2026-08-25

### 新增

**M0–M3 核心功能**
- TCP/UDP 端口映射与加密隧道（TLS/KCP 双通道）
- CLI 客户端（np-client）支持后台运行与 SIGHUP 热重载
- HTTP vhost 同端口按 Host 路由
- 限速（per-mapping kbps）与访客私密穿透（AES-256-GCM）
- KCP 加速通道（多会话复用）
- P2P 打洞直连（信令/探测/直连/回落全链路）
- 虚拟组网（TUN/wintun、虚拟 IP 分配、子网路由）

**M4 管理面**
- 多租户 RBAC 认证（ADMIN/OPERATOR/VIEWER）
- 节点生命周期管理（上线/离线/删除）
- 规则热下发（CONFIG_SYNC 帧）
- License 系统（ECDSA 验签、gen_license.sh 签发工具）
- 审计日志（JSONL 格式、单 IP 限速）
- 管理 HTTP API（/api/nodes、/api/rules、/api/metrics、/api/audit）

**M5 稳定化**
- 连接缓冲配额（读侧 4MB 硬上限、写侧高低水位背压）
- KCP 会话空闲回收（默认 120s，NP_KCP_IDLE_S 可调）
- 认证加固（SHA256+常量时间比较、auth_fail 审计、mgmt 限速）
- 短期节点凭证（ST:expiry:hmac 格式、HMAC-SHA256 绑定）
- 审计日志大小轮转（默认 10MB 保留 3 份）
- bench.sh 吞吐基线（plain/kcp 两模式 16MB 批量传输）
- soak.sh 长稳测试（120s 循环、198 轮零错误）
- 多核部署指引（docs/协议设计.md §10）

**测试与文档**
- 四套回归测试：e2e.sh（plain+tls+kcp）、e2e_p2p.sh、e2e_vn.sh、e2e_mgmt.sh
- 完整协议设计文档（docs/协议设计.md）
- 项目计划书（docs/内网穿透项目计划书.md）
- 中英文 README（README.md / README.en.md）

---

## [0.x] - 开发阶段

M0–M5 开发阶段，详见 git log。
